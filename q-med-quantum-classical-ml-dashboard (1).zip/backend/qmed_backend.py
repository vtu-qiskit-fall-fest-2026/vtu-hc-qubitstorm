"""
Q-Med: Hybrid Quantum-Classical ML Python Backend
=================================================
This Flask API provides real prediction endpoints for the Q-Med dashboard.
It trains both a Classical SVM and a Qiskit Quantum Kernel SVM on the
synthetic `make_moons` dataset, matching the Google Colab workflow.

Requirements:
  pip install flask flask-cors scikit-learn numpy qiskit qiskit-machine-learning

Run locally:
  python qmed_backend.py
  (Runs on http://localhost:5000)

Run in Google Colab with ngrok:
  !pip install flask flask-cors pyngrok scikit-learn qiskit qiskit-machine-learning
  from pyngrok import ngrok
  public_url = ngrok.connect(5000)
  print("Colab Backend Public URL:", public_url)
"""

import time
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from sklearn.datasets import make_moons
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVC

app = Flask(__name__)
# Enable CORS so the React frontend can communicate with this API
CORS(app)

print("[Q-Med] Initializing synthetic make_moons dataset...")
# 1. Generate synthetic make_moons dataset
np.random.seed(42)
X_raw, y_raw = make_moons(n_samples=100, noise=0.15, random_state=42)

# 2. Scale features to [0, pi] for quantum phase encoding
scaler = MinMaxScaler(feature_range=(0, np.pi))
X_train = scaler.fit_transform(X_raw)
y_train = y_raw

print("[Q-Med] Training Classical SVM (RBF)...")
# 3. Train Classical SVM Baseline
classical_svc = SVC(kernel='rbf', C=1.0, gamma='scale')
classical_svc.fit(X_train, y_train)

# 4. Initialize Qiskit Quantum Kernel
qiskit_available = False
quantum_svc = None
feature_map = None
qkernel = None

try:
    from qiskit.circuit.library import ZZFeatureMap
    from qiskit_machine_learning.kernels import FidelityQuantumKernel

    print("[Q-Med] Configuring Qiskit ZZFeatureMap(2 qubits, reps=2)...")
    feature_map = ZZFeatureMap(feature_dimension=2, reps=2, entanglement='linear')
    qkernel = FidelityQuantumKernel(feature_map=feature_map)

    print("[Q-Med] Computing quantum Gram matrix for training set (100 samples)...")
    K_train = qkernel.evaluate(x_vec=X_train)

    quantum_svc = SVC(kernel='precomputed', C=1.0)
    quantum_svc.fit(K_train, y_train)
    qiskit_available = True
    print("[Q-Med] Quantum Kernel SVM successfully trained!")
except Exception as e:
    print(f"[Q-Med] Notice: Qiskit initialization encountered: {e}")
    print("[Q-Med] Classical SVM is fully active.")


@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint to verify backend connectivity."""
    return jsonify({
        "status": "online",
        "service": "Q-Med Quantum ML Backend",
        "dataset": "Synthetic make_moons (100 samples, noise=0.15)",
        "models_loaded": {
            "classical_rbf_svm": True,
            "quantum_kernel_svm": qiskit_available
        },
        "qiskit_available": qiskit_available,
        "feature_count": 2,
        "feature_range_raw": "make_moons (~[-1.5, 2.5] x [-1.0, 1.5])",
        "feature_range_encoded": "[0, pi] radians",
        "disclaimer": "Synthetic educational demonstration only. Not a medical diagnostic tool. Does not predict real EGFR mutations."
    })


@app.route('/predict', methods=['POST'])
def predict():
    """
    Accepts two numerical features:
      {
        "feature1": float,
        "feature2": float,
        "model": "quantum" | "classical"
      }
    Returns real predicted class from the trained model.
    """
    start_time = time.time()
    data = request.get_json(force=True)

    if not data or 'feature1' not in data or 'feature2' not in data:
        return jsonify({"error": "Missing required fields: feature1 and feature2"}), 400

    try:
        f1 = float(data['feature1'])
        f2 = float(data['feature2'])
    except (ValueError, TypeError):
        return jsonify({"error": "feature1 and feature2 must be valid numbers"}), 400

    chosen_model = data.get('model', 'classical').lower()

    # Create raw vector and apply the identical training scaler
    raw_point = np.array([[f1, f2]])
    encoded_point = scaler.transform(raw_point)

    predicted_class = None
    margin_or_fidelity = None
    model_name = ""

    if chosen_model == 'quantum' and qiskit_available and quantum_svc is not None:
        model_name = "Quantum Kernel SVM (Qiskit ZZFeatureMap, 2 Qubits)"
        # Compute quantum kernel inner products between test point and all 100 training vectors
        k_eval = qkernel.evaluate(x_vec=encoded_point, y_vec=X_train)
        pred = quantum_svc.predict(k_eval)
        predicted_class = int(pred[0])
        # Decision function value in dual space
        dec = quantum_svc.decision_function(k_eval)
        margin_or_fidelity = float(dec[0])
    else:
        model_name = "Classical SVM (Radial Basis Function Kernel)"
        pred = classical_svc.predict(encoded_point)
        predicted_class = int(pred[0])
        dec = classical_svc.decision_function(encoded_point)
        margin_or_fidelity = float(dec[0])

    elapsed_ms = (time.time() - start_time) * 1000

    return jsonify({
        "success": True,
        "predicted_class": predicted_class,
        "predicted_label": f"Synthetic Class {predicted_class}",
        "model_used": model_name,
        "raw_features": [f1, f2],
        "encoded_features_radians": [float(encoded_point[0, 0]), float(encoded_point[0, 1])],
        "decision_value": margin_or_fidelity,
        "inference_latency_ms": round(elapsed_ms, 2),
        "dataset": "Synthetic make_moons (noise=0.15)",
        "disclaimer": "Educational demonstration using synthetic make_moons. Not a medical finding and does not predict real patient EGFR mutation status."
    })


if __name__ == '__main__':
    print("[Q-Med] Starting server on http://0.0.0.0:5000...")
    app.run(host='0.0.0.0', port=5000, debug=False)
