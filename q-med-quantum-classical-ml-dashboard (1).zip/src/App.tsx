import React, { useState } from 'react';
import { Header } from './components/Header';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { ProjectOverview } from './components/ProjectOverview';
import { WorkflowDiagram } from './components/WorkflowDiagram';
import { ModelComparison } from './components/ModelComparison';
import { LivePredictor } from './components/LivePredictor';
import { QuantumCircuitViewer } from './components/QuantumCircuitViewer';
import { MethodologyAndLimitations } from './components/MethodologyAndLimitations';
import { ReproducibilitySection } from './components/ReproducibilitySection';
import { HackathonPresentationModal } from './components/HackathonPresentationModal';
import { Footer } from './components/Footer';
import { EXPERIMENT_META, CLASSICAL_METRICS, QUANTUM_METRICS, TEST_SAMPLES } from './data/benchmarkData';

export default function App() {
  const [isPresentationOpen, setIsPresentationOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('overview');

  const scrollToSection = (id: string) => {
    setActiveSection(id);
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleExportReport = () => {
    const reportData = {
      project: 'Q-Med Hybrid Quantum-Classical ML Research Prototype',
      experimentMetadata: EXPERIMENT_META,
      benchmarkResults: {
        classicalSVM: CLASSICAL_METRICS,
        quantumKernelSVM: QUANTUM_METRICS,
      },
      testCohortSamples: TEST_SAMPLES,
      generatedAt: new Date().toISOString(),
      disclaimer: EXPERIMENT_META.disclaimer,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qmed_benchmark_report.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#0b0f17] text-slate-100 flex flex-col selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* 1. Mandatory Scientific & Prototype Disclaimer Banner */}
      <DisclaimerBanner />

      {/* 2. Top Navigation Bar conforming to the Top Bar Contract */}
      <Header
        activeSection={activeSection}
        onNavigate={scrollToSection}
        onOpenDeck={() => setIsPresentationOpen(true)}
        onExportReport={handleExportReport}
      />

      {/* Main Scientific Presentation Content */}
      <main className="flex-1">
        {/* Project Overview & Biological / Quantum Problem Statement */}
        <ProjectOverview
          onExploreWorkflow={() => scrollToSection('workflow')}
          onExploreResults={() => scrollToSection('results')}
        />

        {/* End-to-End Workflow Diagram */}
        <WorkflowDiagram />

        {/* Model Comparison Section: 86.67% vs 73.33%, 45 train, 15 test, sample inspector */}
        <ModelComparison />

        {/* Functional Interactive Quantum ML Predictor (Real Python backend interface) */}
        <LivePredictor />

        {/* Qiskit ZZFeatureMap Circuit Visualizer & Gram Matrix Heatmap */}
        <QuantumCircuitViewer />

        {/* Methodology, Limitations, Honest Evaluation & Future Work */}
        <MethodologyAndLimitations />

        {/* Reproducibility Kit & Full Python Code */}
        <ReproducibilitySection />
      </main>

      {/* Clean Footer */}
      <Footer />

      {/* Full-Screen Judge Pitch / Slide Deck Mode Modal */}
      <HackathonPresentationModal
        isOpen={isPresentationOpen}
        onClose={() => setIsPresentationOpen(false)}
      />
    </div>
  );
}
