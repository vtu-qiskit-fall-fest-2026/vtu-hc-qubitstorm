import React from 'react';
import { AlertCircle, ShieldAlert } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  return (
    <div className="bg-slate-900/90 border-b border-amber-500/30 text-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
          <div className="flex items-start gap-2.5">
            <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-amber-300 mr-2">Research Prototype Disclosure:</span>
              <span className="text-slate-300">
                Small synthetic-data experiment (45 training samples, 15 test samples).
                These findings are algorithmic proofs-of-concept and are <strong>not medical findings</strong>,
                do <strong>not</strong> establish quantum advantage, do <strong>not</strong> claim real EGFR classification,
                and were simulated on a local classical simulator (no physical IBM quantum hardware execution).
              </span>
            </div>
          </div>
          <div className="flex items-center gap-2 text-slate-400 font-mono shrink-0 text-[11px] pl-6 md:pl-0">
            <span>Synthetic N=60</span>
            <span aria-hidden="true">·</span>
            <span>Local Aer Simulator</span>
            <span aria-hidden="true">·</span>
            <span className="text-amber-400">Non-Clinical</span>
          </div>
        </div>
      </div>
    </div>
  );
};
