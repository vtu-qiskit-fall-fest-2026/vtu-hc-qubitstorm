import React from 'react';

export const Footer: React.FC = () => {
  return (
    <footer className="py-8 bg-slate-950 border-t border-slate-800 text-xs text-slate-400">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <span className="font-bold text-white font-mono">Q-Med</span>
          <span className="text-slate-500 mx-2">·</span>
          <span>Quantum-Classical Machine Learning Research Prototype</span>
        </div>

        <div className="flex items-center gap-3 text-slate-500 font-mono text-[11px]">
          <span>Synthetic N=60 Cohort</span>
          <span aria-hidden="true">·</span>
          <span>Qiskit Aer Statevector</span>
          <span aria-hidden="true">·</span>
          <span>Hackathon Showcase</span>
        </div>
      </div>
    </footer>
  );
};
