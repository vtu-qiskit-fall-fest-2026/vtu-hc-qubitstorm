import React, { useState, useEffect } from 'react';
import { HACKATHON_SLIDES } from '../data/benchmarkData';
import {
  X,
  ChevronLeft,
  ChevronRight,
  MessageSquare,
  Presentation,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface HackathonPresentationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HackathonPresentationModal: React.FC<HackathonPresentationModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const [showSpeakerNotes, setShowSpeakerNotes] = useState(true);

  const totalSlides = HACKATHON_SLIDES.length;
  const slide = HACKATHON_SLIDES[currentSlideIndex];

  // Keyboard navigation
  useEffect(() => {
    if (!isOpen) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === ' ') {
        e.preventDefault();
        setCurrentSlideIndex((prev) => (prev < totalSlides - 1 ? prev + 1 : prev));
      } else if (e.key === 'ArrowLeft') {
        e.preventDefault();
        setCurrentSlideIndex((prev) => (prev > 0 ? prev - 1 : prev));
      } else if (e.key === 'Escape') {
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, totalSlides, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4 sm:p-6">
      <div className="w-full max-w-5xl h-[85vh] bg-[#0b0f17] border border-slate-800 rounded-xl flex flex-col overflow-hidden shadow-2xl">
        {/* Top Control Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/80">
          <div className="flex items-center gap-3">
            <Presentation className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">
              Hackathon Judge Pitch Mode
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs font-mono text-slate-400">
              Slide {currentSlideIndex + 1} of {totalSlides}
            </span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => setShowSpeakerNotes(!showSpeakerNotes)}
              className={`px-2.5 py-1 text-xs font-mono rounded border flex items-center gap-1.5 transition-colors ${
                showSpeakerNotes
                  ? 'bg-cyan-950/50 border-cyan-500/50 text-cyan-300'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              <MessageSquare className="w-3.5 h-3.5" />
              <span>Speaker Notes</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-md hover:bg-slate-800 transition-colors"
              title="Close (Esc)"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Progress bar */}
        <div className="w-full h-1 bg-slate-900">
          <div
            className="h-full bg-cyan-400 transition-all duration-300"
            style={{ width: `${((currentSlideIndex + 1) / totalSlides) * 100}%` }}
          />
        </div>

        {/* Slide Stage Area */}
        <div className="flex-1 p-8 sm:p-12 overflow-y-auto flex flex-col justify-between">
          <div>
            {/* Kicker & Title */}
            <div className="text-xs font-mono text-cyan-400 uppercase tracking-wider mb-2">
              {slide.kicker}
            </div>
            <h2 className="text-2xl sm:text-4xl font-bold text-white mb-6 tracking-tight text-balance">
              {slide.title}
            </h2>

            {/* Slide Bullets */}
            <div className="space-y-4 max-w-3xl mb-8">
              {slide.bullets.map((bullet, idx) => (
                <div key={idx} className="flex items-start gap-3">
                  <div className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-2 shrink-0" />
                  <p className="text-base sm:text-lg text-slate-200 leading-relaxed font-normal">
                    {bullet}
                  </p>
                </div>
              ))}
            </div>

            {/* Key Metric highlight if present */}
            {slide.keyMetric && (
              <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg max-w-lg mb-6">
                <div className="text-xs font-mono text-slate-400 uppercase mb-1">
                  {slide.keyMetric.label}
                </div>
                <div className="text-3xl font-mono font-bold text-emerald-400 tabular-nums">
                  {slide.keyMetric.value}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  {slide.keyMetric.context}
                </div>
              </div>
            )}
          </div>

          {/* Speaker Notes Area */}
          {showSpeakerNotes && (
            <div className="p-4 bg-slate-950 border border-slate-800 rounded-lg font-mono text-xs text-slate-300 mt-4">
              <div className="flex items-center gap-1.5 text-cyan-400 text-[11px] font-bold mb-1">
                <MessageSquare className="w-3.5 h-3.5" />
                <span>SPEAKER TALKING POINTS FOR JUDGES:</span>
              </div>
              <p className="leading-relaxed text-slate-300">{slide.speakerNotes}</p>
            </div>
          )}
        </div>

        {/* Bottom Slide Navigation */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-slate-800 bg-slate-950/80">
          <div className="text-xs font-mono text-slate-500">
            Use <kbd className="px-1.5 py-0.5 bg-slate-900 rounded border border-slate-700">←</kbd> and{' '}
            <kbd className="px-1.5 py-0.5 bg-slate-900 rounded border border-slate-700">→</kbd> to navigate
          </div>

          <div className="flex items-center gap-2">
            <button
              disabled={currentSlideIndex === 0}
              onClick={() => setCurrentSlideIndex((prev) => prev - 1)}
              className="px-3 py-1.5 text-xs font-medium rounded border border-slate-800 bg-slate-900 text-slate-300 hover:text-white disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <button
              disabled={currentSlideIndex === totalSlides - 1}
              onClick={() => setCurrentSlideIndex((prev) => prev + 1)}
              className="px-4 py-1.5 text-xs font-semibold rounded bg-cyan-400 text-slate-950 hover:bg-cyan-300 disabled:opacity-40 disabled:cursor-not-allowed transition-colors flex items-center gap-1"
            >
              <span>Next Slide</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
