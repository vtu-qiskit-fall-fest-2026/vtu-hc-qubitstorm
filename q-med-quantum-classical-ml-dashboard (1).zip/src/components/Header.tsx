import React from 'react';
import { Presentation, Download, FileText } from 'lucide-react';

interface HeaderProps {
  onOpenDeck: () => void;
  onExportReport: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenDeck,
  onExportReport,
  activeSection,
  onNavigate,
}) => {
  const navItems = [
    { id: 'overview', label: 'Overview' },
    { id: 'workflow', label: 'Workflow' },
    { id: 'results', label: 'Results' },
    { id: 'live-demo', label: 'Live Predictor' },
    { id: 'quantum-kernel', label: 'Quantum Kernel' },
    { id: 'methodology', label: 'Methodology' },
    { id: 'reproducibility', label: 'Reproducibility' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-[#0b0f17]/90 backdrop-blur-md border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between gap-8 h-16">
          {/* Zone 1: Single text wordmark */}
          <a
            href="#overview"
            onClick={(e) => {
              e.preventDefault();
              onNavigate('overview');
            }}
            className="text-lg font-bold tracking-tight text-white whitespace-nowrap shrink-0 flex items-center gap-2"
          >
            <span className="text-cyan-400 font-mono">Q-Med</span>
            <span className="text-slate-300 font-medium">Research Prototype</span>
          </a>

          {/* Zone 2: Clean single-line nav links */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => onNavigate(item.id)}
                  className={`transition-colors whitespace-nowrap shrink-0 relative py-1 text-xs uppercase tracking-wider ${
                    isActive
                      ? 'text-cyan-400 font-semibold'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-cyan-400" />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Primary action */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={onExportReport}
              className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 rounded-md hover:bg-slate-800 hover:text-white transition-colors whitespace-nowrap shrink-0"
              title="Download structured JSON report"
            >
              <Download className="w-3.5 h-3.5 text-slate-400" />
              <span>Export JSON</span>
            </button>
            <button
              onClick={onOpenDeck}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors whitespace-nowrap shrink-0"
            >
              <Presentation className="w-3.5 h-3.5" />
              <span>Presentation Deck</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
