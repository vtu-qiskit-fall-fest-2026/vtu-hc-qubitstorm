import React, { useState, useEffect } from 'react';
import {
  Play,
  Cpu,
  Binary,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  Download,
  Terminal,
  ExternalLink,
  HelpCircle,
  Layers,
  Sparkles,
} from 'lucide-react';

interface PredictionResponse {
  success: boolean;
  predicted_class: number;
  predicted_label: string;
  model_used: string;
  raw_features: [number, number];
  encoded_features_radians: [number, number];
  decision_value: number;
  inference_latency_ms: number;
  dataset: string;
  disclaimer: string;
}

export const LivePredictor: React.FC = () => {
  // Two numerical features matching synthetic make_moons coordinates
  const [feature1, setFeature1] = useState<string>('-0.50');
  const [feature2, setFeature2] = useState<string>('0.80');
  const [modelType, setModelType] = useState<'quantum' | 'classical'>('quantum');

  // Backend connection state
  const [backendUrl, setBackendUrl] = useState<string>('http://localhost:5000');
  const [connectionStatus, setConnectionStatus] = useState<
    'idle' | 'checking' | 'connected' | 'disconnected'
  >('idle');
  const [backendMeta, setBackendMeta] = useState<any>(null);

  // Prediction state
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [predictionResult, setPredictionResult] = useState<PredictionResponse | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Active sub-view
  const [activeTab, setActiveTab] = useState<'interactive' | 'instructions' | 'python_code'>(
    'interactive'
  );
  const [copiedCode, setCopiedCode] = useState<boolean>(false);

  // Preset points in make_moons distribution
  const presets = [
    { label: 'Upper Moon (Class 0)', f1: '-0.50', f2: '0.80', desc: 'Typical upper crescent' },
    { label: 'Lower Moon (Class 1)', f1: '1.50', f2: '-0.20', desc: 'Typical lower crescent' },
    { label: 'Decision Boundary', f1: '0.50', f2: '0.25', desc: 'Non-linear separation margin' },
    { label: 'Outlier Margin', f1: '-1.00', f2: '0.10', desc: 'Extreme coordinate boundary' },
  ];

  // Check health on mount or when URL changes
  const checkHealth = async (urlToCheck: string) => {
    setConnectionStatus('checking');
    setErrorMessage(null);
    try {
      const cleanUrl = urlToCheck.replace(/\/$/, '');
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);

      const res = await fetch(`${cleanUrl}/health`, {
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        setConnectionStatus('connected');
        setBackendMeta(data);
      } else {
        setConnectionStatus('disconnected');
        setBackendMeta(null);
      }
    } catch (err: any) {
      setConnectionStatus('disconnected');
      setBackendMeta(null);
    }
  };

  useEffect(() => {
    checkHealth(backendUrl);
  }, []);

  const handleRunPrediction = async () => {
    const f1Num = parseFloat(feature1);
    const f2Num = parseFloat(feature2);

    if (isNaN(f1Num) || isNaN(f2Num)) {
      setErrorMessage('Please enter two valid numerical numbers for Feature 1 and Feature 2.');
      return;
    }

    if (connectionStatus !== 'connected') {
      setErrorMessage(
        'Python backend is offline. In compliance with research integrity, Q-Med never generates fake or hardcoded predictions in JavaScript. Please start your Python backend server or consult the Setup Instructions tab below.'
      );
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setPredictionResult(null);

    try {
      const cleanUrl = backendUrl.replace(/\/$/, '');
      const res = await fetch(`${cleanUrl}/predict`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          feature1: f1Num,
          feature2: f2Num,
          model: modelType,
        }),
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with status ${res.status}`);
      }

      const data: PredictionResponse = await res.json();
      setPredictionResult(data);
    } catch (err: any) {
      setErrorMessage(
        `Prediction request failed: ${err.message || 'Could not communicate with Python service'}`
      );
    } finally {
      setIsLoading(false);
    }
  };

  const pythonScript = `"""
qmed_backend.py - Real Qiskit Quantum Kernel SVM REST API
"""
import time
import numpy as np
from flask import Flask, request, jsonify
from flask_cors import CORS
from sklearn.datasets import make_moons
from sklearn.preprocessing import MinMaxScaler
from sklearn.svm import SVC

app = Flask(__name__)
CORS(app)  # Allows React frontend to send requests

# 1. Synthesize make_moons dataset
np.random.seed(42)
X_raw, y_train = make_moons(n_samples=100, noise=0.15, random_state=42)

# 2. Scale features into [0, pi] for quantum angle encoding
scaler = MinMaxScaler(feature_range=(0, np.pi))
X_train = scaler.fit_transform(X_raw)

# 3. Train Classical SVM Baseline
classical_svc = SVC(kernel='rbf', C=1.0, gamma='scale')
classical_svc.fit(X_train, y_train)

# 4. Train Qiskit Quantum Kernel SVM
from qiskit.circuit.library import ZZFeatureMap
from qiskit_machine_learning.kernels import FidelityQuantumKernel

feature_map = ZZFeatureMap(feature_dimension=2, reps=2, entanglement='linear')
qkernel = FidelityQuantumKernel(feature_map=feature_map)
K_train = qkernel.evaluate(x_vec=X_train)

quantum_svc = SVC(kernel='precomputed', C=1.0)
quantum_svc.fit(K_train, y_train)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        "status": "online",
        "dataset": "Synthetic make_moons (100 samples)",
        "qiskit_available": True
    })

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)
    f1, f2 = float(data['feature1']), float(data['feature2'])
    raw_pt = np.array([[f1, f2]])
    encoded_pt = scaler.transform(raw_pt)
    
    if data.get('model') == 'quantum':
        k_eval = qkernel.evaluate(x_vec=encoded_pt, y_vec=X_train)
        pred = int(quantum_svc.predict(k_eval)[0])
        dec = float(quantum_svc.decision_function(k_eval)[0])
        model_name = "Quantum Kernel SVM (Qiskit ZZFeatureMap, 2 Qubits)"
    else:
        pred = int(classical_svc.predict(encoded_pt)[0])
        dec = float(classical_svc.decision_function(encoded_pt)[0])
        model_name = "Classical SVM (Radial Basis Function Kernel)"
        
    return jsonify({
        "success": True,
        "predicted_class": pred,
        "predicted_label": f"Synthetic Class {pred}",
        "model_used": model_name,
        "raw_features": [f1, f2],
        "encoded_features_radians": [float(encoded_pt[0,0]), float(encoded_pt[0,1])],
        "decision_value": dec,
        "dataset": "Synthetic make_moons (noise=0.15)",
        "disclaimer": "Synthetic educational demonstration only. Not a medical finding or EGFR prediction."
    })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
`;

  const handleCopyCode = () => {
    navigator.clipboard.writeText(pythonScript);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadCode = () => {
    const blob = new Blob([pythonScript], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qmed_backend.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="live-demo" className="py-12 border-b border-slate-800 bg-slate-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>FUNCTIONAL PROTOTYPE DEMO</span>
            <span aria-hidden="true">·</span>
            <span>REAL PYTHON & QISKIT BACKEND INTERFACE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Interactive Quantum ML Inference Console
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Enter two continuous numerical coordinates to test decision boundaries on the synthetic{' '}
            <code className="text-cyan-300 font-mono text-xs bg-slate-900 px-1.5 py-0.5 rounded">
              make_moons
            </code>{' '}
            dataset. In adherence to research transparency, predictions are evaluated solely by the
            real Python backend and are never faked or randomized in JavaScript.
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 mb-6 p-1 bg-slate-900 border border-slate-800 rounded-lg w-fit">
          <button
            onClick={() => setActiveTab('interactive')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'interactive'
                ? 'bg-slate-800 text-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Live Inference Console
          </button>
          <button
            onClick={() => setActiveTab('instructions')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'instructions'
                ? 'bg-slate-800 text-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Beginner Setup Guide (Colab & Local)
          </button>
          <button
            onClick={() => setActiveTab('python_code')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'python_code'
                ? 'bg-slate-800 text-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Python Backend Code (qmed_backend.py)
          </button>
        </div>

        {/* Backend Connection Status Ribbon */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 text-xs font-mono">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-400">Backend Endpoint:</span>
              <input
                type="text"
                value={backendUrl}
                onChange={(e) => setBackendUrl(e.target.value)}
                placeholder="http://localhost:5000"
                className="px-2.5 py-1 bg-slate-950 border border-slate-700 rounded text-slate-200 text-xs w-64 focus:outline-none focus:border-cyan-400"
              />
              <button
                onClick={() => checkHealth(backendUrl)}
                disabled={connectionStatus === 'checking'}
                className="px-2.5 py-1 bg-slate-800 border border-slate-700 rounded text-slate-300 hover:text-white transition-colors flex items-center gap-1"
              >
                <RefreshCw
                  className={`w-3 h-3 ${connectionStatus === 'checking' ? 'animate-spin' : ''}`}
                />
                <span>Test Connection</span>
              </button>
            </div>

            <div className="flex items-center gap-3">
              {connectionStatus === 'connected' ? (
                <div className="flex items-center gap-1.5 text-emerald-400">
                  <CheckCircle2 className="w-4 h-4" />
                  <span className="font-semibold">Python Backend Connected</span>
                  {backendMeta?.qiskit_available && (
                    <span className="text-slate-400 text-[11px]">
                      (Qiskit ZZFeatureMap Available)
                    </span>
                  )}
                </div>
              ) : connectionStatus === 'checking' ? (
                <div className="flex items-center gap-1.5 text-cyan-400">
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                  <span>Probing Python API...</span>
                </div>
              ) : (
                <div className="flex items-center gap-1.5 text-amber-400">
                  <AlertTriangle className="w-4 h-4" />
                  <span className="font-semibold">Python Backend Offline</span>
                  <span className="text-slate-400 text-[11px]">(Click "Setup Guide" to start)</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {activeTab === 'interactive' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Feature Inputs & Model Selection (6 cols) */}
            <div className="lg:col-span-6 p-6 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-6">
                <div>
                  <span className="text-xs font-mono text-cyan-400">INPUT SPECIFICATION</span>
                  <h3 className="text-lg font-bold text-white">2D Feature Coordinates</h3>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Dataset: make_moons</span>
              </div>

              {/* Numerical Inputs */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-xs font-mono text-slate-300 mb-1">
                    Feature 1 (Horizontal axis)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={feature1}
                    onChange={(e) => setFeature1(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-md text-white font-mono text-sm focus:outline-none focus:border-cyan-400 tabular-nums"
                  />
                  <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                    Domain range: ~[-1.5, 2.5]
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-mono text-slate-300 mb-1">
                    Feature 2 (Vertical axis)
                  </label>
                  <input
                    type="number"
                    step="0.05"
                    value={feature2}
                    onChange={(e) => setFeature2(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-950 border border-slate-700 rounded-md text-white font-mono text-sm focus:outline-none focus:border-cyan-400 tabular-nums"
                  />
                  <span className="text-[10px] text-slate-500 font-mono mt-1 block">
                    Domain range: ~[-1.0, 1.5]
                  </span>
                </div>
              </div>

              {/* Presets */}
              <div className="mb-6">
                <div className="text-[11px] font-mono uppercase text-slate-400 mb-2">
                  Sample Coordinates from Synthetic Moon Manifolds:
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  {presets.map((preset, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        setFeature1(preset.f1);
                        setFeature2(preset.f2);
                      }}
                      className="p-2 bg-slate-950 border border-slate-800 hover:border-slate-700 rounded text-left transition-colors"
                    >
                      <div className="font-semibold text-slate-200">{preset.label}</div>
                      <div className="text-[10px] text-slate-400">
                        ({preset.f1}, {preset.f2}) · {preset.desc}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Model Selector */}
              <div className="mb-6">
                <div className="text-[11px] font-mono uppercase text-slate-400 mb-2">
                  Select Classification Engine:
                </div>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <button
                    onClick={() => setModelType('quantum')}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      modelType === 'quantum'
                        ? 'bg-cyan-950/40 border-cyan-400 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold mb-1">
                      <Binary className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Quantum Kernel SVM</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Qiskit ZZFeatureMap (2 Qubits, reps=2)
                    </div>
                  </button>

                  <button
                    onClick={() => setModelType('classical')}
                    className={`p-3 rounded-lg border text-left transition-all ${
                      modelType === 'classical'
                        ? 'bg-emerald-950/40 border-emerald-400 text-white shadow-sm'
                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 font-bold mb-1">
                      <Cpu className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Classical SVM</span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono">
                      Radial Basis Function (RBF)
                    </div>
                  </button>
                </div>
              </div>

              {/* Action Button */}
              <div>
                <button
                  onClick={handleRunPrediction}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-bold text-sm rounded-md transition-colors flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Executing Real Python Model...</span>
                    </>
                  ) : (
                    <>
                      <Play className="w-4 h-4 fill-slate-950" />
                      <span>Run Prediction via Python Model</span>
                    </>
                  )}
                </button>
              </div>

              {/* Error Box */}
              {errorMessage && (
                <div className="mt-4 p-3 bg-amber-950/40 border border-amber-800/60 rounded text-xs text-amber-200">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>{errorMessage}</div>
                  </div>
                  {connectionStatus !== 'connected' && (
                    <div className="mt-2 pt-2 border-t border-amber-800/40 flex items-center justify-between">
                      <span className="text-[11px] text-amber-300">Need to start the backend?</span>
                      <button
                        onClick={() => setActiveTab('instructions')}
                        className="text-[11px] underline font-bold text-white hover:text-cyan-300"
                      >
                        View Setup Instructions →
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Right Column: Prediction Output Console (6 cols) */}
            <div className="lg:col-span-6 p-6 bg-slate-950 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-6">
                <div>
                  <span className="text-xs font-mono text-cyan-400">EXECUTION AUDIT</span>
                  <h3 className="text-lg font-bold text-white">Model Prediction Readout</h3>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Real Python Output</span>
              </div>

              {predictionResult ? (
                <div className="space-y-4">
                  {/* Primary result badge */}
                  <div className="p-4 bg-slate-900 border border-slate-800 rounded-lg">
                    <div className="text-xs font-mono uppercase text-slate-400 mb-1">
                      Predicted Classification Result
                    </div>
                    <div className="text-3xl font-mono font-bold text-cyan-400 tabular-nums">
                      Class {predictionResult.predicted_class}
                    </div>
                    <div className="text-xs text-slate-300 mt-1 font-mono">
                      Label: {predictionResult.predicted_label}
                    </div>
                  </div>

                  {/* Model & Latency Telemetry */}
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="p-3 bg-slate-900/60 border border-slate-800 rounded">
                      <div className="text-[10px] text-slate-400 uppercase">Evaluating Model</div>
                      <div className="font-semibold text-white mt-0.5">
                        {predictionResult.model_used}
                      </div>
                    </div>
                    <div className="p-3 bg-slate-900/60 border border-slate-800 rounded">
                      <div className="text-[10px] text-slate-400 uppercase">Inference Latency</div>
                      <div className="font-semibold text-emerald-400 mt-0.5 tabular-nums">
                        {predictionResult.inference_latency_ms} ms
                      </div>
                    </div>
                  </div>

                  {/* Coordinate Transformation details */}
                  <div className="p-3 bg-slate-900/60 border border-slate-800 rounded text-xs font-mono space-y-1.5">
                    <div className="text-[10px] text-slate-400 uppercase">Input Vectors</div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Raw coordinates:</span>
                      <span className="text-slate-200">
                        [{predictionResult.raw_features[0]}, {predictionResult.raw_features[1]}]
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Scaled radians [0, π]:</span>
                      <span className="text-cyan-300">
                        [{predictionResult.encoded_features_radians[0].toFixed(3)},{' '}
                        {predictionResult.encoded_features_radians[1].toFixed(3)}]
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Decision function value:</span>
                      <span className="text-slate-200">
                        {predictionResult.decision_value.toFixed(4)}
                      </span>
                    </div>
                  </div>

                  {/* Mandatory Educational Disclaimer */}
                  <div className="p-3 bg-amber-950/30 border border-amber-800/40 rounded text-xs text-amber-300 leading-relaxed">
                    <div className="font-bold text-[11px] mb-0.5">
                      Educational Demonstration Notice:
                    </div>
                    {predictionResult.disclaimer}
                  </div>
                </div>
              ) : (
                <div className="py-16 text-center text-slate-400">
                  <Binary className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                  <div className="text-sm font-semibold text-slate-300 mb-1">
                    No Prediction Generated Yet
                  </div>
                  <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                    Configure your two coordinates and click <strong>"Run Prediction"</strong>.
                    If your Python backend is not running, view the setup instructions below to
                    launch it in Google Colab or your terminal.
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Tab 2: Beginner-Friendly Setup Guide */}
        {activeTab === 'instructions' && (
          <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-lg">
            <h3 className="text-xl font-bold text-white mb-2">
              Beginner Setup Guide: Running the Python Qiskit Backend
            </h3>
            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              Quantum machine learning algorithms require Python and specialized quantum libraries
              (like Qiskit). Follow these step-by-step instructions to run the real Python backend
              either on Google Colab or locally on your computer.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {/* Option A: Google Colab with ngrok */}
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-cyan-400 font-bold">OPTION A</span>
                  <span className="text-[11px] font-mono text-emerald-400">Recommended for Students</span>
                </div>
                <h4 className="text-base font-bold text-white mb-2">Run in Google Colab (Free GPU/CPU)</h4>
                <ol className="space-y-3 text-xs text-slate-300 list-decimal list-inside leading-relaxed">
                  <li>
                    Open a new Google Colab notebook at{' '}
                    <a
                      href="https://colab.research.google.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-cyan-400 underline inline-flex items-center gap-0.5"
                    >
                      colab.research.google.com <ExternalLink className="w-3 h-3" />
                    </a>
                  </li>
                  <li>
                    In the first cell, install dependencies:
                    <pre className="p-2 bg-slate-900 rounded font-mono text-[11px] text-cyan-300 my-1 overflow-x-auto">
                      !pip install flask flask-cors pyngrok scikit-learn qiskit qiskit-machine-learning
                    </pre>
                  </li>
                  <li>
                    Copy the Python API code from the <strong>"Python Backend Code"</strong> tab into Colab.
                  </li>
                  <li>
                    Expose port 5000 using ngrok:
                    <pre className="p-2 bg-slate-900 rounded font-mono text-[11px] text-cyan-300 my-1 overflow-x-auto">
                      from pyngrok import ngrok{'\n'}public_url = ngrok.connect(5000){'\n'}print("Public API URL:", public_url)
                    </pre>
                  </li>
                  <li>
                    Paste the generated public URL into the <strong>Backend Endpoint</strong> field above and click <strong>Test Connection</strong>.
                  </li>
                </ol>
              </div>

              {/* Option B: Local Machine Terminal */}
              <div className="p-5 bg-slate-950 border border-slate-800 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-xs font-mono text-cyan-400 font-bold">OPTION B</span>
                  <span className="text-[11px] font-mono text-slate-400">Local Environment</span>
                </div>
                <h4 className="text-base font-bold text-white mb-2">Run on Local Computer Terminal</h4>
                <ol className="space-y-3 text-xs text-slate-300 list-decimal list-inside leading-relaxed">
                  <li>
                    Open your terminal and create a virtual environment:
                    <pre className="p-2 bg-slate-900 rounded font-mono text-[11px] text-cyan-300 my-1 overflow-x-auto">
                      python3 -m venv qmed_env{'\n'}source qmed_env/bin/activate  # On Windows: qmed_env\Scripts\activate
                    </pre>
                  </li>
                  <li>
                    Install the required packages:
                    <pre className="p-2 bg-slate-900 rounded font-mono text-[11px] text-cyan-300 my-1 overflow-x-auto">
                      pip install flask flask-cors scikit-learn qiskit qiskit-machine-learning numpy
                    </pre>
                  </li>
                  <li>
                    Save <code className="text-cyan-300 font-mono">backend/qmed_backend.py</code> and execute it:
                    <pre className="p-2 bg-slate-900 rounded font-mono text-[11px] text-cyan-300 my-1 overflow-x-auto">
                      python backend/qmed_backend.py
                    </pre>
                  </li>
                  <li>
                    The server runs on <code className="text-cyan-300 font-mono">http://localhost:5000</code>. Click <strong>Test Connection</strong> to verify!
                  </li>
                </ol>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Full Python Backend Code */}
        {activeTab === 'python_code' && (
          <div className="p-6 bg-slate-950 border border-slate-800 rounded-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800 mb-4">
              <div>
                <span className="text-xs font-mono text-cyan-400">backend/qmed_backend.py</span>
                <div className="text-xs text-slate-400 mt-0.5 font-mono">
                  Flask REST API · Scikit-Learn · Qiskit FidelityQuantumKernel
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopyCode}
                  className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 rounded-md hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-1.5"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400 font-semibold">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleDownloadCode}
                  className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download .py</span>
                </button>
              </div>
            </div>

            <pre className="p-4 bg-slate-900/40 rounded-lg border border-slate-850 font-mono text-xs text-slate-300 overflow-x-auto max-h-[460px] leading-relaxed">
              <code>{pythonScript}</code>
            </pre>
          </div>
        )}
      </div>
    </section>
  );
};
