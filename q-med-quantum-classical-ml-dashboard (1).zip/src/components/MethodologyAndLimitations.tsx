import React from 'react';
import { AlertTriangle, CheckCircle, HelpCircle, Compass, Shield, ArrowRight } from 'lucide-react';

export const MethodologyAndLimitations: React.FC = () => {
  return (
    <section id="methodology" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>SCIENTIFIC RIGOR & ETHICS</span>
            <span aria-hidden="true">·</span>
            <span>EMPIRICAL APPRAISAL</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Methodology, Limitations & Honest Scientific Appraisal
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            In academic science and hackathons alike, transparency is paramount. Here we document
            why the Classical SVM outperformed the Quantum Kernel SVM on this prototype benchmark,
            outline technical limitations, and present prospective directions.
          </p>
        </div>

        {/* 3-Column Diagnostic: Why Did Classical Outperform Quantum? */}
        <div className="mb-12">
          <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-4">
            Analysis: Why Classical SVM (86.67%) Outperformed Quantum Kernel SVM (73.33%)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 bg-slate-900/40 border border-slate-800 rounded-lg">
              <div className="text-xs font-mono text-amber-400 mb-1">FACTOR 01</div>
              <h3 className="text-base font-bold text-white mb-2">Finite Sample Overfitting</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                With only 45 training samples, embedding into a 16-dimensional quantum Hilbert space
                creates a high ratio of feature dimensions to observations. This caused the quantum
                decision boundary to overfit subtle phase variations, producing 4 false positives
                on the test set.
              </p>
            </div>

            <div className="p-5 bg-slate-900/40 border border-slate-800 rounded-lg">
              <div className="text-xs font-mono text-amber-400 mb-1">FACTOR 02</div>
              <h3 className="text-base font-bold text-white mb-2">Inductive Bias Alignment</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                The synthetic non-linear surrogate data is generated in Euclidean space with Gaussian
                noise. The Classical RBF kernel's radial distance decay directly aligns with this
                geometry, whereas the fixed ZZFeatureMap has a periodic, entangled inductive bias.
              </p>
            </div>

            <div className="p-5 bg-slate-900/40 border border-slate-800 rounded-lg">
              <div className="text-xs font-mono text-amber-400 mb-1">FACTOR 03</div>
              <h3 className="text-base font-bold text-white mb-2">Untrained Kernel Parameters</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                The prototype uses fixed angle mappings without Quantum Kernel Alignment (QKA).
                Classical SVM optimizes its support weights against an established convex objective,
                while the quantum kernel space was uncalibrated to data density variations.
              </p>
            </div>
          </div>
        </div>

        {/* 2-Column: Explicit Limitations vs Prospective Future Work */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          {/* Limitations Card */}
          <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-amber-400 mb-2">
                <span>CONSTRAINTS</span>
                <span aria-hidden="true">·</span>
                <span>PROTOTYPE BOUNDARIES</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Current Limitations & Honest Scope</h3>

              <ul className="space-y-3 text-xs text-slate-300">
                <li className="flex items-start gap-2.5">
                  <span className="text-amber-400 font-bold shrink-0">✕</span>
                  <span>
                    <strong>No Medical Claims:</strong> This prototype is an algorithmic exploration.
                    It has not undergone clinical validation and must never be used for medical decisions.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-amber-400 font-bold shrink-0">✕</span>
                  <span>
                    <strong>Synthetic Data Only:</strong> No real patient genomic or EGFR sequencing
                    data was utilized. All 60 samples were synthesized computationally.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-amber-400 font-bold shrink-0">✕</span>
                  <span>
                    <strong>No Quantum Advantage:</strong> The classical SVM demonstrated both higher
                    accuracy (+13.34%) and drastically lower training time (~0.01s vs ~8.4s).
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-amber-400 font-bold shrink-0">✕</span>
                  <span>
                    <strong>Simulation Only:</strong> Calculations ran on a local Qiskit Aer statevector
                    simulator without physical IBM Quantum QPU hardware, shot noise, or decoherence.
                  </span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-slate-400 text-[11px] font-mono">
              Scope strictly bounded to synthetic exploratory study.
            </div>
          </div>

          {/* Future Work Card */}
          <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
                <span>ROADMAP</span>
                <span aria-hidden="true">·</span>
                <span>NEXT RESEARCH ITERATIONS</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-4">Prospective Future Work</h3>

              <ul className="space-y-3 text-xs text-slate-300">
                <li className="flex items-start gap-2.5">
                  <span className="text-cyan-400 font-bold shrink-0">1.</span>
                  <span>
                    <strong>Trainable Quantum Kernel Alignment (QKA):</strong> Implement variational
                    parameterized feature maps where rotation angles are trained jointly with the SVM
                    dual objective to fit genuine data topology.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-cyan-400 font-bold shrink-0">2.</span>
                  <span>
                    <strong>Prospective Real EGFR Datasets:</strong> Apply for research ethics (IRB)
                    to evaluate publicly available, de-identified non-small cell lung cancer datasets
                    (e.g., NCBI GEO, TCGA) with verified EGFR exon 19/21 mutational statuses.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-cyan-400 font-bold shrink-0">3.</span>
                  <span>
                    <strong>Physical QPU Execution with Error Mitigation:</strong> Benchmark on real
                    IBM Quantum superconducting hardware using Zero-Noise Extrapolation (ZNE) and
                    measurement error mitigation.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <span className="text-cyan-400 font-bold shrink-0">4.</span>
                  <span>
                    <strong>High-Dimension Scaling:</strong> Explore projected quantum kernels (PQKs)
                    and Tensor Networks to handle cohorts with 50+ features without exponential state collapse.
                  </span>
                </li>
              </ul>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800 text-slate-400 text-[11px] font-mono">
              Theoretical foundation for future peer-reviewed investigation.
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
