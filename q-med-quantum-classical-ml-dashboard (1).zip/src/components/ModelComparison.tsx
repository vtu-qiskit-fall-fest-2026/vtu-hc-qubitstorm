import React, { useState } from 'react';
import {
  CLASSICAL_METRICS,
  QUANTUM_METRICS,
  TEST_SAMPLES,
  EXPERIMENT_META,
} from '../data/benchmarkData';
import { TestSample } from '../types';
import {
  CheckCircle2,
  XCircle,
  HelpCircle,
  Scale,
  Sparkles,
  BarChart2,
  Layers,
  ArrowUpDown,
  Info,
} from 'lucide-react';

export const ModelComparison: React.FC = () => {
  const [filterType, setFilterType] = useState<'all' | 'discrepant' | 'matching'>('all');
  const [selectedSample, setSelectedSample] = useState<TestSample | null>(TEST_SAMPLES[0]);

  const filteredSamples = TEST_SAMPLES.filter((sample) => {
    if (filterType === 'discrepant') return !sample.agreement;
    if (filterType === 'matching') return sample.agreement;
    return true;
  });

  return (
    <section id="results" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>BENCHMARK RESULTS</span>
            <span aria-hidden="true">·</span>
            <span>SYNTHETIC SURROGATE EXPERIMENT</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Classical SVM vs. Quantum Kernel SVM Comparison
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Direct head-to-head empirical metrics on the test partition ({EXPERIMENT_META.testSamples} samples
            held out from {EXPERIMENT_META.trainSamples} training samples). Classical RBF outperforms
            the simulated Quantum Kernel by 13.34 percentage points in accuracy.
          </p>
        </div>

        {/* Small Synthetic Data Experiment Callout */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-white">Cohort Partition:</span>
            <span className="text-slate-300 font-mono">
              45 Training Samples (75%) · 15 Test Samples (25%) · N = 60 Total
            </span>
          </div>
          <div className="text-slate-400">
            Metric precision verified on held-out synthetic test set.
          </div>
        </div>

        {/* Side-by-Side Model Comparison Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
          {/* Classical SVM Card */}
          <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-lg flex flex-col justify-between relative overflow-hidden">
            <div>
              <div className="flex items-center justify-between gap-4 mb-3">
                <div>
                  <div className="text-xs font-mono text-emerald-400">BASELINE MODEL</div>
                  <h3 className="text-xl font-bold text-white">{CLASSICAL_METRICS.name}</h3>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono text-slate-400">{CLASSICAL_METRICS.kernelType}</span>
                </div>
              </div>

              {/* Primary Metrics: Accuracy & F1 */}
              <div className="grid grid-cols-2 gap-4 my-6">
                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded">
                  <div className="text-xs font-mono uppercase text-slate-400 mb-1">Accuracy</div>
                  <div className="text-3xl font-mono font-bold text-emerald-400 tabular-nums">
                    {CLASSICAL_METRICS.accuracy.toFixed(2)}%
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">13 / 15 correct test samples</div>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded">
                  <div className="text-xs font-mono uppercase text-slate-400 mb-1">F1-Score</div>
                  <div className="text-3xl font-mono font-bold text-emerald-400 tabular-nums">
                    {CLASSICAL_METRICS.f1Score.toFixed(2)}%
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">Harmonic mean precision/recall</div>
                </div>
              </div>

              {/* Secondary Metrics */}
              <div className="grid grid-cols-3 gap-2 mb-6">
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Precision</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    {CLASSICAL_METRICS.precision.toFixed(2)}%
                  </div>
                </div>
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Recall</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    {CLASSICAL_METRICS.recall.toFixed(2)}%
                  </div>
                </div>
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Training Time</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    ~{CLASSICAL_METRICS.trainingTimeSec}s
                  </div>
                </div>
              </div>

              {/* Classical Confusion Matrix */}
              <div>
                <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-2">
                  Test Confusion Matrix (N=15)
                </div>
                <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                  <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded">
                    <div className="text-emerald-400 font-bold text-lg tabular-nums">
                      {CLASSICAL_METRICS.confusionMatrix.tp}
                    </div>
                    <div className="text-[11px] text-slate-400">True Positive</div>
                  </div>
                  <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded">
                    <div className="text-rose-400 font-bold text-lg tabular-nums">
                      {CLASSICAL_METRICS.confusionMatrix.fp}
                    </div>
                    <div className="text-[11px] text-slate-400">False Positive</div>
                  </div>
                  <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded">
                    <div className="text-rose-400 font-bold text-lg tabular-nums">
                      {CLASSICAL_METRICS.confusionMatrix.fn}
                    </div>
                    <div className="text-[11px] text-slate-400">False Negative</div>
                  </div>
                  <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded">
                    <div className="text-emerald-400 font-bold text-lg tabular-nums">
                      {CLASSICAL_METRICS.confusionMatrix.tn}
                    </div>
                    <div className="text-[11px] text-slate-400">True Negative</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 text-xs text-slate-400">
              Deterministic RBF kernel computation; rapid training with zero circuit overhead.
            </div>
          </div>

          {/* Quantum Kernel SVM Card */}
          <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-lg flex flex-col justify-between relative overflow-hidden">
            <div>
              <div className="flex items-center justify-between gap-4 mb-3">
                <div>
                  <div className="text-xs font-mono text-amber-400">EXPERIMENTAL PROTOTYPE</div>
                  <h3 className="text-xl font-bold text-white">{QUANTUM_METRICS.name}</h3>
                </div>
                <div className="text-right">
                  <span className="text-xs font-mono text-slate-400">4 Qubits · Reps=2</span>
                </div>
              </div>

              {/* Primary Metrics: Accuracy & F1 */}
              <div className="grid grid-cols-2 gap-4 my-6">
                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded">
                  <div className="text-xs font-mono uppercase text-slate-400 mb-1">Accuracy</div>
                  <div className="text-3xl font-mono font-bold text-amber-400 tabular-nums">
                    {QUANTUM_METRICS.accuracy.toFixed(2)}%
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">11 / 15 correct test samples</div>
                </div>

                <div className="p-4 bg-slate-950 border border-slate-800/80 rounded">
                  <div className="text-xs font-mono uppercase text-slate-400 mb-1">F1-Score</div>
                  <div className="text-3xl font-mono font-bold text-amber-400 tabular-nums">
                    {QUANTUM_METRICS.f1Score.toFixed(2)}%
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">High recall, lowered precision</div>
                </div>
              </div>

              {/* Secondary Metrics */}
              <div className="grid grid-cols-3 gap-2 mb-6">
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Precision</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    {QUANTUM_METRICS.precision.toFixed(2)}%
                  </div>
                </div>
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Recall</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    {QUANTUM_METRICS.recall.toFixed(2)}%
                  </div>
                </div>
                <div className="p-2.5 bg-slate-900/80 border border-slate-800/80 rounded text-center">
                  <div className="text-[11px] text-slate-400">Sim Training</div>
                  <div className="text-sm font-mono font-semibold text-slate-200 mt-0.5 tabular-nums">
                    ~{QUANTUM_METRICS.trainingTimeSec}s
                  </div>
                </div>
              </div>

              {/* Quantum Confusion Matrix */}
              <div>
                <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-2">
                  Test Confusion Matrix (N=15)
                </div>
                <div className="grid grid-cols-2 gap-2 text-center text-xs font-mono">
                  <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded">
                    <div className="text-emerald-400 font-bold text-lg tabular-nums">
                      {QUANTUM_METRICS.confusionMatrix.tp}
                    </div>
                    <div className="text-[11px] text-slate-400">True Positive</div>
                  </div>
                  <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded">
                    <div className="text-rose-400 font-bold text-lg tabular-nums">
                      {QUANTUM_METRICS.confusionMatrix.fp}
                    </div>
                    <div className="text-[11px] text-slate-400">False Positive (4)</div>
                  </div>
                  <div className="p-3 bg-rose-950/30 border border-rose-800/40 rounded">
                    <div className="text-rose-400 font-bold text-lg tabular-nums">
                      {QUANTUM_METRICS.confusionMatrix.fn}
                    </div>
                    <div className="text-[11px] text-slate-400">False Negative (0)</div>
                  </div>
                  <div className="p-3 bg-emerald-950/30 border border-emerald-800/40 rounded">
                    <div className="text-emerald-400 font-bold text-lg tabular-nums">
                      {QUANTUM_METRICS.confusionMatrix.tn}
                    </div>
                    <div className="text-[11px] text-slate-400">True Negative</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-800/80 text-xs text-amber-400/90">
              Higher recall (100%) but lower precision (63.64%) due to over-sensitivity in phase rotations.
            </div>
          </div>
        </div>

        {/* Interactive 15-Sample Test Explorer */}
        <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <div className="text-xs font-mono uppercase text-slate-400">Sample-by-Sample Inspection</div>
              <h3 className="text-lg font-bold text-white">
                Individual Synthetic Test Cohort Predictions (15 Samples)
              </h3>
            </div>

            {/* Filter buttons - segmented control */}
            <div className="flex items-center gap-1 p-1 bg-slate-950 border border-slate-800 rounded-lg text-xs font-medium self-start sm:self-auto">
              <button
                onClick={() => setFilterType('all')}
                className={`px-3 py-1 rounded transition-colors ${
                  filterType === 'all'
                    ? 'bg-slate-800 text-white font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                All (15)
              </button>
              <button
                onClick={() => setFilterType('discrepant')}
                className={`px-3 py-1 rounded transition-colors ${
                  filterType === 'discrepant'
                    ? 'bg-amber-950/80 text-amber-300 font-semibold border border-amber-800/50'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Discrepant (3)
              </button>
              <button
                onClick={() => setFilterType('matching')}
                className={`px-3 py-1 rounded transition-colors ${
                  filterType === 'matching'
                    ? 'bg-emerald-950/80 text-emerald-300 font-semibold border border-emerald-800/50'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Concordant (12)
              </button>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Table Column (7 cols) */}
            <div className="lg:col-span-7 overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-950 border-b border-slate-800 font-mono text-slate-400 uppercase text-[11px]">
                  <tr>
                    <th className="py-2.5 px-3">Sample ID</th>
                    <th className="py-2.5 px-3">True Label</th>
                    <th className="py-2.5 px-3">Classical</th>
                    <th className="py-2.5 px-3">Quantum</th>
                    <th className="py-2.5 px-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {filteredSamples.map((sample) => {
                    const isSelected = selectedSample?.id === sample.id;
                    const isClassicalCorrect = sample.classicalPred === sample.trueLabel;
                    const isQuantumCorrect = sample.quantumPred === sample.trueLabel;

                    return (
                      <tr
                        key={sample.id}
                        onClick={() => setSelectedSample(sample)}
                        className={`cursor-pointer transition-colors ${
                          isSelected
                            ? 'bg-cyan-950/40 text-white'
                            : 'hover:bg-slate-800/40 text-slate-300'
                        }`}
                      >
                        <td className="py-2.5 px-3 font-semibold text-white">
                          {sample.sampleCode}
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={
                              sample.trueLabel === 1 ? 'text-cyan-400' : 'text-slate-400'
                            }
                          >
                            Class {sample.trueLabel}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={
                              isClassicalCorrect ? 'text-emerald-400' : 'text-rose-400 font-bold'
                            }
                          >
                            {sample.classicalPred} {isClassicalCorrect ? '✓' : '✗'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <span
                            className={
                              isQuantumCorrect ? 'text-emerald-400' : 'text-amber-400 font-bold'
                            }
                          >
                            {sample.quantumPred} {isQuantumCorrect ? '✓' : '✗'}
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          {sample.agreement ? (
                            <span className="text-slate-400 text-[11px]">Concordant</span>
                          ) : (
                            <span className="text-amber-400 font-bold text-[11px]">Divergent</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Sample Inspector Detail Box (5 cols) */}
            <div className="lg:col-span-5 p-4 bg-slate-950 border border-slate-800 rounded-lg">
              {selectedSample ? (
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                    <div>
                      <span className="text-[11px] font-mono text-cyan-400">INSPECTOR</span>
                      <h4 className="text-base font-bold text-white font-mono">
                        {selectedSample.sampleCode}
                      </h4>
                    </div>
                    <div className="text-right">
                      <div className="text-[11px] text-slate-400 font-mono">True Ground Truth</div>
                      <div className="text-xs font-mono font-bold text-cyan-300">
                        Class {selectedSample.trueLabel} ({selectedSample.trueLabelName})
                      </div>
                    </div>
                  </div>

                  {/* Feature vector values */}
                  <div className="mb-4">
                    <div className="text-[11px] font-mono uppercase text-slate-400 mb-1.5">
                      Normalized Feature Vector (Domain [0, π])
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                      {selectedSample.features.map((feat, idx) => (
                        <div key={idx} className="p-2 bg-slate-900 border border-slate-800 rounded">
                          <span className="text-slate-400 text-[10px]">x_{idx}: </span>
                          <span className="text-slate-200 font-semibold tabular-nums">
                            {feat.toFixed(2)} rad
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Predictions compare */}
                  <div className="grid grid-cols-2 gap-3 mb-4 text-xs font-mono">
                    <div
                      className={`p-2.5 rounded border ${
                        selectedSample.classicalPred === selectedSample.trueLabel
                          ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                          : 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                      }`}
                    >
                      <div className="text-[10px] uppercase text-slate-400">Classical SVM</div>
                      <div className="font-bold text-sm mt-0.5">
                        Predicted: {selectedSample.classicalPred}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1">
                        Margin score: {selectedSample.classicalConfidence.toFixed(2)}
                      </div>
                    </div>

                    <div
                      className={`p-2.5 rounded border ${
                        selectedSample.quantumPred === selectedSample.trueLabel
                          ? 'bg-emerald-950/30 border-emerald-800/40 text-emerald-300'
                          : 'bg-amber-950/30 border-amber-800/40 text-amber-300'
                      }`}
                    >
                      <div className="text-[10px] uppercase text-slate-400">Quantum Kernel</div>
                      <div className="font-bold text-sm mt-0.5">
                        Predicted: {selectedSample.quantumPred}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1">
                        Fidelity score: {selectedSample.quantumFidelityScore.toFixed(2)}
                      </div>
                    </div>
                  </div>

                  {/* Explanatory notes */}
                  <div className="p-2.5 bg-slate-900/60 border border-slate-800 rounded text-xs text-slate-300">
                    <div className="text-[10px] font-mono text-slate-400 uppercase mb-1">
                      Scientific Analysis
                    </div>
                    {selectedSample.notes}
                  </div>
                </div>
              ) : (
                <div className="text-xs text-slate-400 text-center py-12">
                  Select a sample row to inspect features and discrepancy rationale.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
