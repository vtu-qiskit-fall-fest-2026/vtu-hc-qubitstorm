import React from 'react';
import { Cpu, Dna, GitCompare, Sparkles, AlertTriangle, ArrowRight, BookOpen } from 'lucide-react';
import { EXPERIMENT_META } from '../data/benchmarkData';

interface ProjectOverviewProps {
  onExploreWorkflow: () => void;
  onExploreResults: () => void;
}

export const ProjectOverview: React.FC<ProjectOverviewProps> = ({
  onExploreWorkflow,
  onExploreResults,
}) => {
  return (
    <section id="overview" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header Kicker & Title */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>HYBRID QUANTUM-CLASSICAL ML</span>
            <span aria-hidden="true">·</span>
            <span>HACKATHON RESEARCH PROTOTYPE</span>
            <span aria-hidden="true">·</span>
            <span>SYNTHETIC BENCHMARK</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight text-white mb-4 text-balance">
            Q-Med: Empirical Evaluation of Quantum Kernel Methods for Biomarker Classification
          </h1>
          <p className="text-base text-slate-300 leading-relaxed">
            Q-Med is an exploratory student research prototype investigating whether
            quantum feature space embedding via Qiskit's <code className="text-cyan-300 font-mono text-xs bg-slate-900 px-1.5 py-0.5 rounded">ZZFeatureMap</code> can
            compete with or complement classical Radial Basis Function (RBF) Support Vector Machines
            on non-linear biological surrogate patterns.
          </p>
        </div>

        {/* 4-Item Telemetry / Specification Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-xs uppercase font-mono text-slate-400 mb-1">Dataset Partition</div>
            <div className="text-2xl font-mono font-bold text-white tabular-nums">45 / 15</div>
            <div className="text-xs text-slate-400 mt-1">45 Train · 15 Test (N=60 synthetic)</div>
          </div>

          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-xs uppercase font-mono text-slate-400 mb-1">Feature Reduction</div>
            <div className="text-2xl font-mono font-bold text-cyan-400 tabular-nums">4 Qubits</div>
            <div className="text-xs text-slate-400 mt-1">PCA to 4 dims, scaled [0, π]</div>
          </div>

          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-xs uppercase font-mono text-slate-400 mb-1">Classical SVM (RBF)</div>
            <div className="text-2xl font-mono font-bold text-emerald-400 tabular-nums">86.67%</div>
            <div className="text-xs text-slate-400 mt-1">F1: 85.71% · Scikit-Learn SVC</div>
          </div>

          <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="text-xs uppercase font-mono text-slate-400 mb-1">Quantum Kernel SVM</div>
            <div className="text-2xl font-mono font-bold text-amber-400 tabular-nums">73.33%</div>
            <div className="text-xs text-slate-400 mt-1">F1: 77.78% · Qiskit Aer Simulator</div>
          </div>
        </div>

        {/* Problem Statement & Research Questions (2-Column Balanced) */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch">
          {/* Card 1: The Problem Statement */}
          <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mb-2">
                <span>SECTION 01</span>
                <span aria-hidden="true">/</span>
                <span>MOTIVATION & CHALLENGE</span>
              </div>
              <h2 className="text-xl font-bold text-white mb-3">
                The Biological & Computational Problem
              </h2>
              <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                <p>
                  High-throughput genomic and proteomic profiles are characterized by extreme
                  dimensionality, intricate cross-gene correlations, and subtle non-linear response
                  surfaces.
                </p>
                <p>
                  Classical Support Vector Machines using Gaussian RBF kernels project points into
                  an infinite-dimensional Reproducing Kernel Hilbert Space (RKHS) using Euclidean distance
                  metrics:
                </p>
                <div className="p-3 bg-slate-950 border border-slate-800/80 rounded font-mono text-xs text-cyan-300 overflow-x-auto">
                  K_classical(x, z) = exp(-γ · ||x - z||²)
                </div>
                <p>
                  While effective, classical Euclidean metrics can struggle to isolate non-linear
                  synergies when decision boundaries exhibit multi-body phase correlations.
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6">
              <button
                onClick={onExploreWorkflow}
                className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <span>Inspect End-to-End Workflow Pipeline</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Card 2: Quantum Kernel Hypothesis & Prospective Domain */}
          <div className="p-6 bg-slate-900/40 border border-slate-800 rounded-lg flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono text-slate-400 mb-2">
                <span>SECTION 02</span>
                <span aria-hidden="true">/</span>
                <span>QUANTUM HILBERT EMBEDDING</span>
              </div>
              <h2 className="text-xl font-bold text-white mb-3">
                Quantum Feature Mapping & Prospective Targets
              </h2>
              <div className="space-y-3 text-sm text-slate-300 leading-relaxed">
                <p>
                  Quantum kernel methods embed classical data vectors <code className="text-cyan-300 font-mono text-xs bg-slate-900 px-1 py-0.5 rounded">x ∈ ℝ⁴</code> into a
                  $2^4 = 16$-dimensional quantum state space via unitary circuit evolution:
                </p>
                <div className="p-3 bg-slate-950 border border-slate-800/80 rounded font-mono text-xs text-cyan-300 overflow-x-auto">
                  |Φ(x)⟩ = U_Φ(x) |0⟩^⊗4  →  K_quantum(x_i, x_j) = |⟨Φ(x_i)|Φ(x_j)⟩|²
                </div>
                <p className="text-slate-400 text-xs leading-normal">
                  <strong className="text-slate-200">Prospective Downstream Target:</strong> In non-small cell lung cancer (NSCLC),
                  targeted kinase inhibitors depend on detecting somatic mutations in the <em className="text-slate-200">EGFR</em> gene
                  (e.g., exon 19 deletions or L858R substitutions). While Q-Med’s long-term aspiration is analyzing such biomarker signatures,
                  <span className="text-amber-300 font-medium"> no patient EGFR genomic data has been utilized in this prototype</span>.
                  All current benchmarks use controlled synthetic surrogates.
                </p>
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 mt-6">
              <button
                onClick={onExploreResults}
                className="inline-flex items-center gap-2 text-xs font-semibold text-cyan-400 hover:text-cyan-300 transition-colors"
              >
                <span>Jump to Experimental Comparison Data</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
