import React, { useState } from 'react';
import { QUANTUM_KERNEL_MATRIX, TEST_SAMPLES } from '../data/benchmarkData';
import { Sliders, RefreshCw, Eye, Grid3X3, Layers } from 'lucide-react';

export const QuantumCircuitViewer: React.FC = () => {
  // Feature parameter scrubbers for x0, x1, x2, x3 in [0, pi]
  const [featureAngles, setFeatureAngles] = useState<[number, number, number, number]>([
    0.55, 1.48, 2.62, 0.72,
  ]);

  const [hoveredMatrixCell, setHoveredMatrixCell] = useState<{
    row: number;
    col: number;
    val: number;
  } | null>(null);

  const [activeTab, setActiveTab] = useState<'circuit' | 'matrix'>('circuit');

  const updateAngle = (idx: number, val: number) => {
    const updated = [...featureAngles] as [number, number, number, number];
    updated[idx] = val;
    setFeatureAngles(updated);
  };

  const resetToPreset = (sampleIdx: number) => {
    const s = TEST_SAMPLES[sampleIdx];
    setFeatureAngles([...s.features] as [number, number, number, number]);
  };

  // Compute theoretical phase shifts
  const singleQubitPhases = featureAngles.map((x) => (2 * x).toFixed(2));
  const entanglerPhases = [
    (2 * (Math.PI - featureAngles[0]) * (Math.PI - featureAngles[1])).toFixed(2),
    (2 * (Math.PI - featureAngles[1]) * (Math.PI - featureAngles[2])).toFixed(2),
    (2 * (Math.PI - featureAngles[2]) * (Math.PI - featureAngles[3])).toFixed(2),
  ];

  return (
    <section id="quantum-kernel" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>CIRCUIT ARCHITECTURE & INNER PRODUCTS</span>
            <span aria-hidden="true">·</span>
            <span>QISKIT AER SIMULATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Qiskit ZZFeatureMap & Gram Matrix Explorer
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            Investigate how 4 classical feature dimensions are encoded into quantum states via
            single-qubit $R_z$ rotations and two-qubit $ZZ$ entangling gates across 2 repetitions.
            Hover over the Gram matrix to see computed transition fidelities.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2 mb-6 p-1 bg-slate-900 border border-slate-800 rounded-lg w-fit">
          <button
            onClick={() => setActiveTab('circuit')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'circuit'
                ? 'bg-slate-800 text-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Parameterized Circuit Diagram (ZZFeatureMap)
          </button>
          <button
            onClick={() => setActiveTab('matrix')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              activeTab === 'matrix'
                ? 'bg-slate-800 text-cyan-400'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            15×15 Quantum Gram Matrix (Fidelity)
          </button>
        </div>

        {activeTab === 'circuit' ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* Left Column: Interactive Circuit Canvas (8 cols) */}
            <div className="lg:col-span-8 p-6 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6 pb-3 border-b border-slate-800">
                <div>
                  <span className="text-xs font-mono text-slate-400 uppercase">Qiskit Circuit</span>
                  <div className="text-sm font-bold text-white font-mono">
                    ZZFeatureMap(feature_dim=4, reps=2, entanglement='linear')
                  </div>
                </div>
                <div className="text-xs font-mono text-cyan-400">
                  Hilbert Space Dimension: 2⁴ = 16
                </div>
              </div>

              {/* Circuit SVG / Wire Rail Visualizer */}
              <div className="overflow-x-auto py-4 bg-slate-950 p-4 rounded-lg border border-slate-850">
                <div className="min-w-[620px] space-y-7">
                  {[0, 1, 2, 3].map((qubitIdx) => (
                    <div key={qubitIdx} className="relative flex items-center">
                      {/* Qubit label */}
                      <div className="w-16 font-mono text-xs text-slate-400 flex items-center gap-1 shrink-0">
                        <span className="text-cyan-400 font-semibold">q_{qubitIdx}:</span>
                        <span>|0⟩</span>
                      </div>

                      {/* Continuous wire line */}
                      <div className="absolute left-16 right-0 h-0.5 bg-slate-700/80 -z-0" />

                      {/* Circuit elements on the wire */}
                      <div className="relative z-10 flex items-center gap-4 pl-4">
                        {/* Repetition 1: H gate */}
                        <div className="w-8 h-8 rounded bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-xs font-mono font-bold text-cyan-300">
                          H
                        </div>

                        {/* Rz(2 x_i) rotation */}
                        <div className="px-2.5 h-8 rounded bg-indigo-950 border border-indigo-500/50 flex items-center justify-center text-[10px] font-mono text-indigo-200">
                          Rz({singleQubitPhases[qubitIdx]})
                        </div>

                        {/* ZZ entangling indication */}
                        <div className="px-2 h-8 rounded bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] font-mono text-slate-300">
                          {qubitIdx < 3 ? `ZZ_{${qubitIdx},${qubitIdx + 1}}` : `ZZ_{${qubitIdx - 1},${qubitIdx}}`}
                        </div>

                        <div className="text-slate-650 text-xs font-mono px-1">╏</div>

                        {/* Repetition 2: H gate */}
                        <div className="w-8 h-8 rounded bg-cyan-950 border border-cyan-500/50 flex items-center justify-center text-xs font-mono font-bold text-cyan-300">
                          H
                        </div>

                        {/* Repetition 2: Rz rotation */}
                        <div className="px-2.5 h-8 rounded bg-indigo-950 border border-indigo-500/50 flex items-center justify-center text-[10px] font-mono text-indigo-200">
                          Rz({singleQubitPhases[qubitIdx]})
                        </div>

                        {/* Measurement / state readout */}
                        <div className="w-7 h-7 rounded bg-slate-900 border border-slate-700 flex items-center justify-center text-[10px] font-mono text-slate-400">
                          M
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Circuit notes */}
              <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs text-slate-400 font-mono">
                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                  <div className="text-slate-300 font-semibold mb-0.5">Single-Qubit Rotations</div>
                  <div>U₁(x_i) = exp(i · x_i · Z) = Rz(2 · x_i)</div>
                </div>
                <div className="p-2.5 bg-slate-950/60 rounded border border-slate-800">
                  <div className="text-slate-300 font-semibold mb-0.5">Two-Qubit Entanglers</div>
                  <div>U₂(x_i, x_j) = exp(i · (π - x_i)(π - x_j) · Z ⊗ Z)</div>
                </div>
              </div>
            </div>

            {/* Right Column: Parameter Scrubbers (4 cols) */}
            <div className="lg:col-span-4 p-6 bg-slate-900/60 border border-slate-800 rounded-lg">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-white uppercase font-mono">
                    Feature Controls
                  </span>
                </div>
                <span className="text-[11px] font-mono text-slate-400">Domain: [0, π]</span>
              </div>

              <p className="text-xs text-slate-300 mb-4">
                Adjust input feature parameters in radians to inspect phase evolution:
              </p>

              {/* Sliders */}
              <div className="space-y-4 mb-6">
                {featureAngles.map((angle, idx) => (
                  <div key={idx} className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-300">Feature x_{idx} (Dim {idx + 1})</span>
                      <span className="text-cyan-400 font-bold tabular-nums">
                        {angle.toFixed(2)} rad
                      </span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={3.1415}
                      step={0.01}
                      value={angle}
                      onChange={(e) => updateAngle(idx, parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                    />
                  </div>
                ))}
              </div>

              {/* Presets */}
              <div className="pt-4 border-t border-slate-800">
                <div className="text-[11px] font-mono uppercase text-slate-400 mb-2">
                  Load Test Sample Presets
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                  <button
                    onClick={() => resetToPreset(0)}
                    className="p-1.5 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 text-left"
                  >
                    T01 (True Pos)
                  </button>
                  <button
                    onClick={() => resetToPreset(1)}
                    className="p-1.5 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 text-slate-300 text-left"
                  >
                    T02 (True Neg)
                  </button>
                  <button
                    onClick={() => resetToPreset(3)}
                    className="p-1.5 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 text-amber-300 text-left"
                  >
                    T04 (Discrepancy)
                  </button>
                  <button
                    onClick={() => resetToPreset(12)}
                    className="p-1.5 rounded bg-slate-950 border border-slate-800 hover:border-slate-700 text-emerald-300 text-left"
                  >
                    T13 (Quantum Win)
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* 15x15 Gram Matrix Heatmap View */
          <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-lg">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
              <div>
                <span className="text-xs font-mono text-cyan-400 uppercase">Fidelity Gram Matrix</span>
                <h3 className="text-lg font-bold text-white">
                  K(x_i, x_j) = |⟨Φ(x_i) | Φ(x_j)⟩|² for N=15 Test Cohort
                </h3>
              </div>
              <div className="text-xs font-mono text-slate-400">
                Hover over matrix cells to inspect pairwise state overlaps.
              </div>
            </div>

            {/* Matrix & HUD layout */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Heatmap Grid (8 cols) */}
              <div className="lg:col-span-8 overflow-x-auto">
                <div className="inline-block p-3 bg-slate-950 rounded-lg border border-slate-800">
                  <div className="grid grid-cols-15 gap-0.5" style={{ gridTemplateColumns: 'repeat(15, minmax(0, 1fr))' }}>
                    {QUANTUM_KERNEL_MATRIX.map((row, rIdx) =>
                      row.map((val, cIdx) => {
                        // Intensity scale from 0.0 to 1.0 (cyan hue)
                        const opacity = Math.max(0.1, val);
                        const isHovered =
                          hoveredMatrixCell?.row === rIdx && hoveredMatrixCell?.col === cIdx;

                        return (
                          <div
                            key={`${rIdx}-${cIdx}`}
                            onMouseEnter={() =>
                              setHoveredMatrixCell({ row: rIdx, col: cIdx, val })
                            }
                            className={`w-5 h-5 sm:w-7 sm:h-7 rounded-[2px] cursor-crosshair transition-all flex items-center justify-center text-[9px] font-mono ${
                              isHovered ? 'ring-2 ring-white z-10' : ''
                            }`}
                            style={{
                              backgroundColor: `rgba(6, 182, 212, ${opacity * 0.85})`,
                              color: val > 0.5 ? '#000000' : '#ffffff',
                            }}
                          >
                            {val.toFixed(1)}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              {/* Inspector HUD (4 cols) */}
              <div className="lg:col-span-4 p-4 bg-slate-950 border border-slate-800 rounded-lg font-mono text-xs">
                <div className="text-[11px] uppercase text-cyan-400 mb-2 font-bold">
                  Matrix Cell Readout
                </div>

                {hoveredMatrixCell ? (
                  <div className="space-y-3">
                    <div className="p-3 bg-slate-900 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Sample Pair:</div>
                      <div className="text-white font-bold text-sm">
                        {TEST_SAMPLES[hoveredMatrixCell.row]?.sampleCode} ×{' '}
                        {TEST_SAMPLES[hoveredMatrixCell.col]?.sampleCode}
                      </div>
                    </div>

                    <div className="p-3 bg-slate-900 rounded border border-slate-800">
                      <div className="text-slate-400 text-[10px]">Quantum Fidelity Kernel K(i, j):</div>
                      <div className="text-cyan-400 font-bold text-2xl tabular-nums">
                        {hoveredMatrixCell.val.toFixed(3)}
                      </div>
                      <div className="text-[10px] text-slate-400 mt-1">
                        {hoveredMatrixCell.row === hoveredMatrixCell.col
                          ? 'Diagonal: perfect self-overlap (|⟨Φ|Φ⟩|² = 1.0)'
                          : hoveredMatrixCell.val > 0.7
                          ? 'Strong geometric proximity in Hilbert space'
                          : 'Weak state overlap (quasi-orthogonal)'}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-slate-400 py-8 text-center text-xs">
                    Hover over any cell in the 15×15 matrix to inspect transition fidelity.
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
