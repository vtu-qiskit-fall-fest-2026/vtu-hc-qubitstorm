import React, { useState } from 'react';
import { FULL_PYTHON_SCRIPT, EXPERIMENT_META, CLASSICAL_METRICS, QUANTUM_METRICS, TEST_SAMPLES } from '../data/benchmarkData';
import { Terminal, Copy, Check, Download, ExternalLink, Code } from 'lucide-react';

export const ReproducibilitySection: React.FC = () => {
  const [copiedScript, setCopiedScript] = useState(false);
  const [copiedInstall, setCopiedInstall] = useState(false);

  const installCommand = 'pip install qiskit qiskit-machine-learning scikit-learn numpy';

  const handleCopyScript = () => {
    navigator.clipboard.writeText(FULL_PYTHON_SCRIPT);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2000);
  };

  const handleCopyInstall = () => {
    navigator.clipboard.writeText(installCommand);
    setCopiedInstall(true);
    setTimeout(() => setCopiedInstall(false), 2000);
  };

  const handleDownloadScript = () => {
    const blob = new Blob([FULL_PYTHON_SCRIPT], { type: 'text/x-python' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qmed_synthetic_reproducibility.py';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleExportJSON = () => {
    const reportData = {
      project: 'Q-Med Hybrid Quantum-Classical Research Prototype',
      experimentMetadata: EXPERIMENT_META,
      models: {
        classicalSVM: CLASSICAL_METRICS,
        quantumKernelSVM: QUANTUM_METRICS,
      },
      testCohortSamples: TEST_SAMPLES,
      generatedAt: new Date().toISOString(),
      disclaimer: EXPERIMENT_META.disclaimer,
    };

    const blob = new Blob([JSON.stringify(reportData, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'qmed_benchmark_report.json';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <section id="reproducibility" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>OPEN RESEARCH STANDARDS</span>
            <span aria-hidden="true">·</span>
            <span>CODE & ARTIFACT REPLICATION</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            Reproducibility Kit & Python Verification Script
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            All synthetic data generation, preprocessing matrices, classical SVM training, and
            Qiskit quantum kernel simulation parameters are encapsulated in this standalone script.
            Run it locally or on Google Colab to verify the exact numbers reported above.
          </p>
        </div>

        {/* Quick Start Terminal Box */}
        <div className="p-4 bg-slate-900/60 border border-slate-800 rounded-lg mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span className="text-slate-400">Environment Setup:</span>
              <span className="text-slate-200">{installCommand}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyInstall}
                className="px-2.5 py-1 rounded bg-slate-950 border border-slate-700 text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                {copiedInstall ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-slate-400" />
                    <span>Copy Command</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Script Viewer Container */}
        <div className="p-6 bg-slate-950 border border-slate-800 rounded-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800 mb-4">
            <div>
              <span className="text-xs font-mono text-cyan-400">qmed_synthetic_reproducibility.py</span>
              <div className="text-xs text-slate-400 mt-0.5 font-mono">
                Standalone Python 3.10+ · Scikit-Learn 1.3+ · Qiskit 1.0+
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyScript}
                className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 rounded-md hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-1.5"
              >
                {copiedScript ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-semibold">Script Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-slate-400" />
                    <span>Copy Script</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadScript}
                className="px-3 py-1.5 text-xs font-semibold text-slate-950 bg-cyan-400 hover:bg-cyan-300 rounded-md transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download .py</span>
              </button>

              <button
                onClick={handleExportJSON}
                className="px-3 py-1.5 text-xs font-medium text-slate-300 bg-slate-900 border border-slate-700 rounded-md hover:bg-slate-800 hover:text-white transition-colors flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5 text-slate-400" />
                <span>Export JSON</span>
              </button>
            </div>
          </div>

          <pre className="p-4 bg-slate-900/40 rounded-lg border border-slate-850 font-mono text-xs text-slate-300 overflow-x-auto max-h-[460px] leading-relaxed">
            <code>{FULL_PYTHON_SCRIPT}</code>
          </pre>
        </div>
      </div>
    </section>
  );
};
