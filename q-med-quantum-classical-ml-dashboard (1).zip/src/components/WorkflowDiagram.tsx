import React, { useState } from 'react';
import { PIPELINE_STAGES } from '../data/benchmarkData';
import { Database, Filter, Binary, Cpu, BarChart3, ChevronRight, Copy, Check } from 'lucide-react';

export const WorkflowDiagram: React.FC = () => {
  const [selectedStageIndex, setSelectedStageIndex] = useState(0);
  const [copiedCode, setCopiedCode] = useState(false);

  const activeStage = PIPELINE_STAGES[selectedStageIndex];

  const handleCopy = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const stageIcons = [
    <Database className="w-4 h-4" />,
    <Filter className="w-4 h-4" />,
    <Cpu className="w-4 h-4" />,
    <Binary className="w-4 h-4" />,
    <BarChart3 className="w-4 h-4" />,
  ];

  return (
    <section id="workflow" className="py-12 border-b border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mb-8">
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-2">
            <span>RESEARCH METHODOLOGY</span>
            <span aria-hidden="true">·</span>
            <span>HYBRID PIPELINE ARCHITECTURE</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white mb-3">
            End-to-End Hybrid Quantum-Classical Workflow
          </h2>
          <p className="text-sm text-slate-300 leading-relaxed">
            The dual-branch experimental pipeline compares a classical RBF kernel directly against
            a Qiskit quantum kernel evaluated via statevector inner products on identical preprocessed
            synthetic data. Click any stage to inspect execution details and equations.
          </p>
        </div>

        {/* Visual Workflow Diagram */}
        <div className="p-6 bg-slate-900/60 border border-slate-800 rounded-lg mb-8">
          <div className="text-xs font-mono uppercase text-slate-400 mb-4 tracking-wider">
            Execution Flow Diagram (Select node to inspect)
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
            {/* Step 1: Synthetic Dataset */}
            <button
              onClick={() => setSelectedStageIndex(0)}
              className={`text-left p-3.5 rounded-lg border transition-all ${
                selectedStageIndex === 0
                  ? 'bg-cyan-950/40 border-cyan-400 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-mono text-slate-400">STAGE 01</span>
                <span className={selectedStageIndex === 0 ? 'text-cyan-400' : 'text-slate-400'}>
                  {stageIcons[0]}
                </span>
              </div>
              <div className="text-xs font-bold text-white mb-0.5">Synthetic Dataset</div>
              <div className="text-[11px] text-slate-400 font-mono">N=60 (45 train / 15 test)</div>
            </button>

            {/* Step 2: Preprocessing */}
            <button
              onClick={() => setSelectedStageIndex(1)}
              className={`text-left p-3.5 rounded-lg border transition-all ${
                selectedStageIndex === 1
                  ? 'bg-cyan-950/40 border-cyan-400 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-mono text-slate-400">STAGE 02</span>
                <span className={selectedStageIndex === 1 ? 'text-cyan-400' : 'text-slate-400'}>
                  {stageIcons[1]}
                </span>
              </div>
              <div className="text-xs font-bold text-white mb-0.5">PCA & Scaling</div>
              <div className="text-[11px] text-slate-400 font-mono">d=4 dims · [0, π] bound</div>
            </button>

            {/* Step 3A: Classical SVM Branch */}
            <button
              onClick={() => setSelectedStageIndex(2)}
              className={`text-left p-3.5 rounded-lg border transition-all ${
                selectedStageIndex === 2
                  ? 'bg-emerald-950/40 border-emerald-400 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-mono text-emerald-400">BRANCH A</span>
                <span className={selectedStageIndex === 2 ? 'text-emerald-400' : 'text-slate-400'}>
                  {stageIcons[2]}
                </span>
              </div>
              <div className="text-xs font-bold text-white mb-0.5">Classical SVM</div>
              <div className="text-[11px] text-slate-400 font-mono">RBF kernel (C=1.0)</div>
            </button>

            {/* Step 3B: Quantum Kernel Branch */}
            <button
              onClick={() => setSelectedStageIndex(3)}
              className={`text-left p-3.5 rounded-lg border transition-all ${
                selectedStageIndex === 3
                  ? 'bg-amber-950/40 border-amber-400 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-mono text-amber-400">BRANCH B</span>
                <span className={selectedStageIndex === 3 ? 'text-amber-400' : 'text-slate-400'}>
                  {stageIcons[3]}
                </span>
              </div>
              <div className="text-xs font-bold text-white mb-0.5">Quantum Kernel SVM</div>
              <div className="text-[11px] text-slate-400 font-mono">Qiskit ZZFeatureMap</div>
            </button>

            {/* Step 4: Evaluation */}
            <button
              onClick={() => setSelectedStageIndex(4)}
              className={`text-left p-3.5 rounded-lg border transition-all ${
                selectedStageIndex === 4
                  ? 'bg-cyan-950/40 border-cyan-400 shadow-sm'
                  : 'bg-slate-900/80 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-[11px] font-mono text-slate-400">STAGE 04</span>
                <span className={selectedStageIndex === 4 ? 'text-cyan-400' : 'text-slate-400'}>
                  {stageIcons[4]}
                </span>
              </div>
              <div className="text-xs font-bold text-white mb-0.5">Audit & Evaluation</div>
              <div className="text-[11px] text-slate-400 font-mono">Acc · F1 · Discrepancies</div>
            </button>
          </div>
        </div>

        {/* Selected Stage Detail Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Stage description & parameters (7 cols) */}
          <div className="lg:col-span-7 p-6 bg-slate-900/40 border border-slate-800 rounded-lg">
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
              <span>{activeStage.number}</span>
              <span aria-hidden="true">·</span>
              <span>STAGE SPECIFICATION</span>
            </div>
            <h3 className="text-xl font-bold text-white mb-1">{activeStage.title}</h3>
            <p className="text-xs text-slate-400 mb-4">{activeStage.subtitle}</p>

            <p className="text-sm text-slate-300 leading-relaxed mb-6">
              {activeStage.description}
            </p>

            {/* Technical bullets */}
            <div className="mb-6 space-y-2">
              <div className="text-xs font-mono uppercase text-slate-400 tracking-wider">
                Methodological Invariants
              </div>
              <ul className="space-y-1.5 text-xs text-slate-300">
                {activeStage.technicalDetails.map((detail, idx) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="text-cyan-400 mt-0.5">▸</span>
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Parameters Table */}
            <div>
              <div className="text-xs font-mono uppercase text-slate-400 tracking-wider mb-2">
                Hyperparameters & Bounds
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {activeStage.parameters.map((param, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-950 border border-slate-800/80 rounded">
                    <div className="text-[11px] text-slate-400">{param.label}</div>
                    <div className="text-xs font-mono font-medium text-slate-200 mt-0.5">
                      {param.value}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Code Snippet (5 cols) */}
          <div className="lg:col-span-5 p-4 bg-slate-950 border border-slate-800 rounded-lg">
            <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
              <span className="text-xs font-mono text-slate-400">Python Implementation</span>
              <button
                onClick={() => handleCopy(activeStage.codeSnippet)}
                className="inline-flex items-center gap-1.5 text-[11px] font-mono text-slate-300 hover:text-white transition-colors py-0.5 px-2 rounded bg-slate-900 border border-slate-700"
              >
                {copiedCode ? (
                  <>
                    <Check className="w-3 h-3 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-slate-400" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>
            <pre className="text-[11px] font-mono text-cyan-200 overflow-x-auto p-2 bg-slate-900/50 rounded leading-relaxed">
              <code>{activeStage.codeSnippet}</code>
            </pre>
          </div>
        </div>
      </div>
    </section>
  );
};
