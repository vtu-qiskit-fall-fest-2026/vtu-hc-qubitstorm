export interface TestSample {
  id: string;
  sampleCode: string;
  features: [number, number, number, number]; // [x0, x1, x2, x3]
  featureNames: string[];
  trueLabel: 0 | 1;
  trueLabelName: string;
  classicalPred: 0 | 1;
  classicalConfidence: number;
  quantumPred: 0 | 1;
  quantumFidelityScore: number;
  agreement: boolean;
  notes: string;
}

export interface ConfusionMatrixData {
  tp: number;
  fp: number;
  tn: number;
  fn: number;
}

export interface ModelMetrics {
  name: string;
  tag: string;
  kernelType: string;
  accuracy: number; // percentage
  f1Score: number; // percentage
  precision: number; // percentage
  recall: number; // percentage
  specificity: number; // percentage
  confusionMatrix: ConfusionMatrixData;
  trainingSamples: number;
  testSamples: number;
  trainingTimeSec: number;
  inferenceLatencyMs: number;
  circuitDepth?: number;
  qubitCount?: number;
}

export interface PipelineStage {
  id: string;
  number: string;
  title: string;
  subtitle: string;
  description: string;
  technicalDetails: string[];
  codeSnippet: string;
  parameters: { label: string; value: string }[];
}

export interface PresentationSlide {
  id: number;
  title: string;
  kicker: string;
  bullets: string[];
  speakerNotes: string;
  keyMetric?: { label: string; value: string; context: string };
}
